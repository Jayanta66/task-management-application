package com.taskmanagement.taskmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.taskmanagement.taskmanagement.exception.TaskNotFoundException;
import com.taskmanagement.taskmanagement.exception.NoDataException;
import com.taskmanagement.taskmanagement.model.Task;
import com.taskmanagement.taskmanagement.service.TaskServices;





//@Controller
@RestController
//@RequestMapping("/task")
@CrossOrigin("http://localhost:3000")
public class MainController {
	
	
	@Autowired
	TaskServices service;
	
	@GetMapping("/")
	public String home() {
		return "Welcome to the Task Management Application";
	}
	
 	
	@PostMapping("/api/addtasks")
	public ResponseEntity<?> addTask(@RequestBody Task c){
		Task cus = service.addTask(c);
			return new ResponseEntity<>(c,HttpStatus.CREATED);
	}
	
	

	
	
	@PutMapping("/api/tasks/{id}")
	public ResponseEntity<?> updateTask(@PathVariable("id") long id, @RequestBody Task c) throws TaskNotFoundException{
		Task cus = service.updateTask(id, c);
		if(cus!=null)
			return new ResponseEntity<>(cus,HttpStatus.OK);
		else
			throw new TaskNotFoundException("Customer not found with given id");

			
	}
	
	@DeleteMapping("/api/tasks/{id}")
	public ResponseEntity<?> deleteTask(@PathVariable("id") long id) throws TaskNotFoundException{
		String msg = service.deleteTask((long) id);
		if(msg!=null)
			return new ResponseEntity<>("Deleted CUSTOMER ID : "+id,HttpStatus.OK);
		else
			throw new TaskNotFoundException("Customer not found with given id");

	}
	

	
	
	
	@GetMapping("/api/alltasks")
	public ResponseEntity<?> getTask() throws NoDataException{
		List<Task> list = service.getAllTask();
		if((!list.isEmpty()))
			return new ResponseEntity<>(list,HttpStatus.OK);
		else
			throw new NoDataException("No Data Found");
	}
	
	@GetMapping("/api/tasks/{Id}")
	public ResponseEntity<?> getTaskById(@PathVariable("Id") Long id) throws TaskNotFoundException{
		Task cus =  service.getTask(id);
		if(cus!=null)
		return new ResponseEntity<>(cus,HttpStatus.OK);
		else
			throw new TaskNotFoundException("Customer not found with given id");	
		
		
	}
	

}
