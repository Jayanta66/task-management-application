package com.taskmanagement.taskmanagement.exception;

public class TaskNotFoundException extends Exception {

	String msg;

	public TaskNotFoundException(String msg) {
		super();
		this.msg = msg;
	}
	
	
	

}
