package com.taskmanagement.taskmanagement;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;

import org.hibernate.cache.spi.UpdateTimestampsCache;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import org.springframework.test.annotation.Rollback;

import com.taskmanagement.taskmanagement.model.Task;
import com.taskmanagement.taskmanagement.repository.TaskRepository;

@DataJpaTest(showSql = false)
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class TaskRepositoryTest {
	
	@Autowired
	private TestEntityManager entityManager;

	@Autowired	
	private TaskRepository taskRepository;
	
	@Test
	public void testCreateTask() {
		Date createdAt = new Date(); 
		Date updatedAt = new Date();
		Task task = new Task("Java Full Web Development","Java Develper","Completed",createdAt,updatedAt);	
		Task savedtask = taskRepository.save(task);
		assertThat(savedtask.getId()).isGreaterThan(0);
		
	}
	

	@Test
	public void testListAllTask() {
		Iterable<Task> listTasks = taskRepository.findAll();
		listTasks.forEach(task -> System.out.println(task));
	}
	
	@Test
	public void testGetTaskById() {
		Task task = taskRepository.findById((long) 31).get();
		System.out.println(task);
		assertThat(task).isNotNull();
	}
	
	@Test
	public void testUpdateTaskDetails() {
		Task userNam = taskRepository.findById((long) 31).get();
		userNam.setId((long)31);
		userNam.setTitle("Jayanta Halderrrrrrrrrrrrrrrrrrrrr");
		userNam.setDescription("dsfdsf");
		userNam.setStatus("Completed");		
		System.out.println(taskRepository.save(userNam));

	}
	
	@Test
	public void testDeleteTask() {
		Long taskId = (long) 31;
		taskRepository.deleteById(taskId);
		System.out.println("Deleted Successfully");

		
	}
	
	@Test
	public void testGetByTaskTitle() {
		String title = "Java Full Web Development";
		Task user = taskRepository.getTitle(title);
		System.out.println(user);
		assertThat(user).isNotNull();
	}


}
