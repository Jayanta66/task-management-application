package com.taskmanagement.taskmanagement;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;

import org.hibernate.cache.spi.UpdateTimestampsCache;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import org.springframework.test.annotation.Rollback;

import com.taskmanagement.taskmanagement.model.Task;
import com.taskmanagement.taskmanagement.repository.TaskRepository;

@DataJpaTest(showSql = false)
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class TaskRepositoryTest {
	
	@Autowired
	private TestEntityManager entityManager;

	@Autowired	
	private TaskRepository taskRepository;
	
	@Test
	public void testCreateTask() {
		Date createdAt = new Date(); 
		Date updatedAt = new Date();
		Task userNamHM = new Task("Java Full Web Development","Java Develper","Completed",createdAt,updatedAt);	
		Task savedUser = taskRepository.save(userNamHM);
		assertThat(savedUser.getId()).isGreaterThan(0);
		
	}
	

	@Test
	public void testListAllTask() {
		Iterable<Task> listUsers = taskRepository.findAll();
		listUsers.forEach(user -> System.out.println(user));
	}
	
	@Test
	public void testGetTaskById() {
		Task userNam = taskRepository.findById((long) 31).get();
		assertThat(userNam).isNotNull();
	}
	
	@Test
	public void testUpdateTaskDetails() {
		Task userNam = taskRepository.findById((long) 31).get();
		userNam.setId((long)31);
		userNam.setTitle("Jayanta Halderrrrrrrrrrrrrrrrrrrrr");
		userNam.setDescription("dsfdsf");
		userNam.setStatus("Completed");		
		taskRepository.save(userNam);

	}
	
	@Test
	public void testDeleteTask() {
		Long taskId = (long) 30;
		taskRepository.deleteById(taskId);;
		
	}
	
	@Test
	public void testGetByTaskTitle() {
		String title = "I am here";
		Task user = taskRepository.getTitle(title);
		assertThat(user).isNotNull();
	}


}
